
import 'package:get/get.dart';
import 'package:news_app/bindings/my_bindings.dart';
import 'package:flutter/material.dart';
import 'package:news_app/controller/notification_controller.dart';
import 'package:news_app/view/calculate.dart';
import 'package:news_app/view/home.dart';
import 'package:news_app/view/menu.dart';
import 'package:news_app/view/news.dart';
import 'package:news_app/view/profile.dart';



void main() => runApp(const MaterialApp(home: MyMain(),));

class MyMain extends StatelessWidget {
  const MyMain({super.key});

  @override
  Widget build(BuildContext context) {
    const appTitle = 'NewsApp';
    return GetMaterialApp(
        debugShowCheckedModeBanner: false,
        initialBinding: MyBindings(),
      themeMode: ThemeMode.light,
      title: appTitle,

      home: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: const Text(appTitle,),
          foregroundColor: Colors.white ,
          actions: [
            IconButton(
              icon: const Icon(Icons.notifications),
              onPressed: () {
                NotificationController();
              },
            ),
            IconButton(
              onPressed: () {
                // method to show the search bar
                showSearch(
                    context: context,
                    // delegate to customize the search bar
                    delegate: CustomSearchDelegate()
                );
              },
              icon: const Icon(Icons.search),
            ),



          ],
        ),


        body: const MyStatefulWidget(),
        drawer:   const Menu(),


          )

    );
  }
}


//For Bottom navigation bar
class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({super.key});

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();

}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  int _selectedIndex = 0;
  static  final List<Widget> _widgetOptions = <Widget>[
     HomeScreen(),
     NewsScreen(),
    CalculateScreen(),
     ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }


  @override
  Widget build(BuildContext context) {
    return  Scaffold(

      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.white,
        unselectedItemColor: Colors.red,
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.newspaper),
            label: 'News',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calculate),
            label: 'Calculate',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],

      ),
    );
  }
}
class CustomSearchDelegate extends SearchDelegate {
  // Demo list to show querying
  List<String> name = [
    "Ranchi",
    "Jharkhand",
    "India",
    "World",
    "Science",
    "Sports",
    "Social",
    "Trending",
    "Breaking",
    "Fresh",
    "Today",
    "December",
    "Weather",
    "Bollywood",
    "Political",
    "PM",
    "CM"
  ];

  // first overwrite to
  // clear the search text
  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        onPressed: () {
          query = '';
        },
        icon: const Icon(Icons.clear),
      ),
    ];
  }

  // second overwrite to pop out of search menu
  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      onPressed: () {
        close(context, null);
      },
      icon: const Icon(Icons.arrow_back),
    );
  }

  // third overwrite to show query result
  @override
  Widget buildResults(BuildContext context) {
    List<String> matchQuery = [];
    for (var product in name) {
      if (product.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(product);
      }
    }
    return ListView.builder(
      itemCount: matchQuery.length,
      itemBuilder: (context, index) {
        var result = matchQuery[index];
        return ListTile(
          title: Text(result),
        );
      },
    );
  }

  // last overwrite to show the
  // querying process at the runtime
  @override
  Widget buildSuggestions(BuildContext context) {
    List<String> matchQuery = [];
    for (var product in name) {
      if (product.toLowerCase().contains(query.toLowerCase())) {
        matchQuery.add(product);
      }
    }
    return ListView.builder(
      itemCount: matchQuery.length,
      itemBuilder: (context, index) {
        var result = matchQuery[index];
        return ListTile(
          title: Text(result),
        );
      },
    );
  }
}