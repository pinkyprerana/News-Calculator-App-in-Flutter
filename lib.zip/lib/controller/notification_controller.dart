import 'package:get/get.dart';

class NotificationController extends GetxController {
  bool isOn = false;

 NotificationListener() {
    isOn=false;
    update();
  }

  darkTheme() {
    isOn = true;
    update();
  }
}