
import 'package:json_annotation/json_annotation.dart';


@JsonSerializable()
class NewsModel {
  NewsModel({
    required this.news,
  });

  NewsData news;
  //
  factory NewsModel.fromJson(Map<String, dynamic> json) {
    print(json);
    return NewsModel(
        news: NewsData.fromJson(json['news'])
    );
  }
  Map<String, dynamic> toJson() => {
    "news" : news.toJson
  };
}

class NewsData {
  NewsData({
     this.url
  });
  final url;

  factory NewsData.fromJson(Map<String, dynamic> json)=> NewsData(
    url : json['url'],
  );
  Map<String, dynamic> toJson()=>{
    "url" : url,
  };
}