import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()
class ProfileModel {
  const ProfileModel({
    this.name,
    this.emailid,
    this.mobile,
  });
  final name;
  final emailid;
  final mobile;

  factory ProfileModel.fromJson(Map<String, dynamic> json)=> ProfileModel(
    name : json['name'],
    emailid: json['emailid'],
    mobile: json['mobile'],
  );
  Map<String, dynamic> toJson()=>{
    "name" : name,
    "emailid": emailid,
    "mobile": mobile,
  };
}

class ProfileData {
  ProfileData({
    this.url
  });
  final url;

  factory ProfileData.fromJson(Map<String, dynamic> json)=> ProfileData(
    url : json['url'],
  );
  Map<String, dynamic> toJson()=>{
    "url" : url,
  };
}