import 'package:json_annotation/json_annotation.dart';

@JsonSerializable()

class HomeModel {
 const HomeModel({
      this.title,
      this.author,
      this.description,
      this.content,
      this.publishedAt,
      this.url,
      this.urlToImage,
});
  final title;
  final author;
  final description;
  final content;
  final url;
  final urlToImage;
  final publishedAt;

  factory HomeModel.fromJson(Map<String, dynamic> json)=> HomeModel(
    title : json['title'],
    author: json['author'],
    description: json['description'],
    content: json['content'],
    urlToImage: json['urlToImage'],
    url : json['url'],
    publishedAt: json['publishedAt'],
  );
  Map<String, dynamic> toJson()=>{
   "title" : title,
    "author": author,
    "description": description,
    "content": content,
    "urlToImage": urlToImage,
    "publishedAt": publishedAt,
    "url" : url,
  };
}


class HomeData {
  HomeData({
    this.url
  });
  final url;

  factory HomeData.fromJson(Map<String, dynamic> json)=> HomeData(
    url : json['url'],
  );
  Map<String, dynamic> toJson()=>{
    "url" : url,
  };
}