import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

Future<HomeModel> fetchHomeModel() async {
  final response = await http.get(Uri.parse('https://jsonplaceholder.typicode.com/photos?_start=0&_limit=5'));

  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.
    return HomeModel.fromJson(jsonDecode(response.body));
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load Home');
  }
}

class HomeModel {
  final author;
  final description;
  final title;
  final publishedAt;
  final urlToImage;
  final url;
  final content;

  const HomeModel({
    required this.title,
    required this.author,
    required this.description,
    required this.content,
    required this.publishedAt,
    required this.url,
    required this.urlToImage,
  });

  factory HomeModel.fromJson(Map<String, dynamic> json) {
    return HomeModel(
      title: json['title'],
      author: json['author'],
      description: json['description'],
      content: json['content'],
      url: json['url'],
      urlToImage: json['urlToImage'],
      publishedAt: json['publishedAt'],
    );
  }
}