import 'package:dio/dio.dart';
import 'package:news_app/model/news_model.dart';


class NewsApi {
  final Dio _dio = Dio();

  final url = 'https://jsonplaceholder.typicode.com/photos';

  Future<NewsModel?> getUser({required String id}) async {
    NewsModel? news;
    try {
      Response userData = await _dio.get(url);
      news = NewsModel.fromJson(userData.data[0]);

    } on DioError catch (e) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx and is also not 304.
      if (e.response != null) {
        print('Dio error!');
        print('STATUS: ${e.response?.statusCode}');
        print('DATA: ${e.response?.data}');
        print('HEADERS: ${e.response?.headers}');
      } else {
        // Error due to setting up or sending the request
        print('Error sending request!');
        print(e.message);
      }
    }

    return news;
  }
}


