import 'package:flutter/material.dart';
import 'package:news_app/view/calculate.dart';
import 'package:news_app/view/home.dart';
import 'package:news_app/view/news.dart';
import 'package:news_app/view/profile.dart';



void main() => runApp(const MaterialApp(home: Menu(),));


class Menu extends StatelessWidget {
  const Menu({super.key});

  @override
  Widget build(BuildContext context) {
    return  Drawer(
      width: 200,
      child: DrawerHeader(
        padding: EdgeInsets.zero,


        child:
        ListView(
          children: <Widget> [
            UserAccountsDrawerHeader(
              margin: EdgeInsets.zero,
              accountEmail: const Text(''),
              accountName: Row(
                children: <Widget>[
                  Container(
                    width: 50,
                    height: 50,
                    decoration: const BoxDecoration(shape: BoxShape.circle),
                    child: const CircleAvatar(
                      backgroundColor: Colors.green,
                      backgroundImage: AssetImage('assets/images/p.png'),

                      //child: Icon(Icons.check,),

                    ),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: const <Widget>[
                      Text('Pinky Prerana'),
                      Text('pinky@raneso.com'),
                    ],
                  ),

                ],
              ),

            ),

            Column(
              children:  <Widget>[

                GestureDetector(
                  onTap: (){
                    Navigator.of(context).pop();
                    Navigator.of(context).push( MaterialPageRoute(builder: (context) =>  HomeScreen()));
                  },
                  child: const ListTile(
                    title: Text('Home',  selectionColor: Colors.purple),
                    leading: Icon(Icons.home, color: Colors.red),
                  ),
                ),

                const Divider(),

                GestureDetector(
                  onTap: (){
                    Navigator.of(context).pop();
                    Navigator.of(context).push( MaterialPageRoute(builder: (context) =>  const NewsScreen()));
                  },
                  child:const ListTile(
                    title: Text("News", selectionColor: Colors.purple,),
                    leading: Icon(Icons.newspaper, color: Colors.red,),
                  ),
                ),


                const Divider(),

                GestureDetector(
                  onTap: (){
                    Navigator.of(context).pop();
                    Navigator.of(context).push( MaterialPageRoute(builder: (context) =>  CalculateScreen()));
                  },
                  child:const ListTile(
                    title: Text("Calculate", selectionColor: Colors.purple,),
                    leading: Icon(Icons.calculate, color: Colors.red,),
                  ),
                ),


                const Divider(),

                GestureDetector(
                  onTap: (){
                    Navigator.of(context).pop();
                    Navigator.of(context).push( MaterialPageRoute(builder: (context) =>  ProfileScreen()));
                  },
                  child:const ListTile(
                    title: Text("Profile", selectionColor: Colors.purple,),
                    leading: Icon(Icons.person, color: Colors.red,),
                  ),
                ),

              ],
            ),
          ],
        ),
      ),
    );

  }
}
