import 'package:flutter/material.dart';



class NewsScreen extends StatefulWidget {
  const NewsScreen({Key? key}) : super(key: key);

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {

  var news=[
    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    },
    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    },
    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    },
    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    },
    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    },
    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    },
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
    body: ListView.builder(
        itemCount: news.length,
        itemBuilder: (BuildContext context, int index){
          return News(
              author:'Author name',
              title:'Breaking news',
              description:'Short description',
              url:'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
              urlToImage: 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
              publishedAt: '2022-12-07T05:49:03Z',
              content: 'This is content of news'
          );
        }
    )

    );
  }
}


class News extends StatelessWidget {
  final String? author;
  final String? title;
  final String? description;
  final String? content;
  final String? url;
  final String? urlToImage;
  final String? publishedAt;

  News({
    this.author,
    this.title,
    this.description,
    this.content,
    this.url,
    this.urlToImage,
    this.publishedAt,
  });


  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
      width: MediaQuery.of(context).size.width,
      height: 180,
      decoration: BoxDecoration(
        color: Colors.blue,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            offset: const Offset(
              0.0,
              10.0,
            ),
            blurRadius: 10.0,
            spreadRadius: -6.0,
          ),
        ],
        image: DecorationImage(
          colorFilter: ColorFilter.mode(
            Colors.black.withOpacity(0.35),
            BlendMode.multiply,
          ),
          image: NetworkImage(urlToImage!),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          Align(
            alignment: Alignment.center,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5.0),
              child: Text(
                title!,
                style: const TextStyle(
                  fontSize: 19,
                ),
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
                textAlign: TextAlign.center,
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomLeft,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(5),
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.person,
                        color: Colors.yellow,
                        size: 15,
                      ),
                      const SizedBox(width: 7),
                      Text(author!, ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(5),
                  margin: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.schedule,
                        color: Colors.yellow,
                        size: 15,
                      ),
                      const SizedBox(width: 7),
                      Text(publishedAt!),
                    ],
                  ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}




