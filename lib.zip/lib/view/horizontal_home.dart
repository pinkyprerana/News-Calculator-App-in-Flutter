
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';

void main() => runApp( MaterialApp(home: HorizontalHome(),));


class HorizontalHome extends StatefulWidget {
  @override
  _HorizontalHomeState createState() => _HorizontalHomeState();
}

class _HorizontalHomeState extends State<HorizontalHome> {

  var newslist=[
    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    },

    {
      'author': 'Author name',
      'title': 'Breaking news',
      'description': 'Short description',
      'url': 'https://www.ndtv.com/world-news/elon-musk-slams-investigation-into-bedrooms-at-twitter-hq-3584592',
      'urlToImage': 'https://c.ndtvimg.com/2022-11/vs6hsv1g_elon-musk-twitter-reuters_625x300_21_November_22.jpg',
      'publishedAt': '2022-12-07T05:49:03Z',
      'content': 'This is content of news'
    }

  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: newslist.length,
        gridDelegate:
        const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1),
        itemBuilder: (BuildContext context, int index) {
          return Scaffold(
            body: Column(
              children: [
                Row(
                  children: <Widget>[
                    Expanded(
                      flex: 0,
                      child: Container(
                        height: 600,
                        width: MediaQuery.of(context).size.width,
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Home(
                            author: newslist[index]['author'],
                            title: newslist[index]['title'],
                            description: newslist[index]['description'],
                            publishedAt: newslist[index]['publishedAt'],
                            url: newslist[index]['url'],
                            urlToImage: newslist[index]['urlToImage'],
                            content: newslist[index]['content'],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),

          );
        }
    );
  }
}
class Home extends StatelessWidget {
  final String? author;
  final String? title;
  final String? description;
  final String? content;
  final String? url;
  final String? urlToImage;
  final String? publishedAt;

  Home({
    this.author,
    this.title,
    this.description,
    this.content,
    this.url,
    this.urlToImage,
    this.publishedAt,
  });

  ///redirect to this url OnTap
  final Uri _url = Uri.parse('https://biztoc.com/x/fe74553088d79899');

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: BoxDecoration(
          color: Colors.blue,
          borderRadius: BorderRadius.circular(15),
          image: DecorationImage(
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.35),
              BlendMode.multiply,
            ),
            image: NetworkImage(urlToImage!),
            fit: BoxFit.cover,
          ),
        ),
        child: Card(
          child: Hero(
            tag: title!,
            child: Material(
              child: InkWell(

                onTap: () {
                  _launchUrl;
                  const Text('Show detail news');
                },

                //   Navigator.of(context).pop();
                //   Navigator.of(context).push( MaterialPageRoute(builder: (context) => DetailNews()));
                // },

                child: GridTile(
                  footer: Container(
                    color: Colors.white70,
                    child: ListTile(
                      leading: Text(
                        title!,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      title: Text(
                        "$author",
                        style: const TextStyle(
                            color: Colors.red, fontWeight: FontWeight.w800),
                      ),
                      subtitle: Text(
                        "$publishedAt",
                        style: const TextStyle(
                          color: Colors.black54,
                          fontWeight: FontWeight.w800,
                        ),
                      ),

                    ),
                  ),
                  child: Image.network(
                    urlToImage!,
                    fit: BoxFit.cover,
                  ),

                ),


              ),


            ),

          ),

        )
    );
  }


  Future<void> _launchUrl() async {
    if (!await launchUrl(_url)) {
      throw 'Could not launch $_url';
    }
  }



}






