
import 'package:flutter/material.dart';
import 'package:news_app/network/home_api.dart';
// import 'package:news_app/view/horizontal_home.dart';

void main() => runApp( MaterialApp(home: HomeScreen(),));


class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<HomeModel> futureHomeModel;


  @override
  void initState() {
    super.initState();
    futureHomeModel = fetchHomeModel();
  }

  @override
  Widget build(BuildContext context) {
          return Scaffold(
            body: Center(
              child: FutureBuilder<HomeModel>(
                future: futureHomeModel,
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    return Text(snapshot.data!.title);
                  } else if (snapshot.hasError) {
                    return Text('${snapshot.error}');
                  }

                  // By default, show a loading spinner.
                  return const CircularProgressIndicator();
                },
              ),
            ),
    );
  }

}